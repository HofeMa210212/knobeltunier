
import 'package:hive/hive.dart';
import 'package:knobeltunier_v2/data/player/matchplayer.dart';

part 'match.g.dart';

@HiveType(typeId: 1)
class Match extends HiveObject{
  @HiveField(0)
   MatchPlayer player1;
  @HiveField(1)
   MatchPlayer player2;
  @HiveField(2)
  MatchPlayer? winner;
  @HiveField(3)
  MatchPlayer? loser;
  @HiveField(4)
  String? place;
  @HiveField(5)
  DateTime? time;
  @HiveField(6)
  int? id;
  @HiveField(7)
  int matchNr;

  Match({
    required this.player1,
    required this.player2,
    this.place,
    this.time,
    this.id,
    required this.matchNr
  });

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    if (other is! Match) return false;
    return player1 == other.player1 && player2 == other.player2;
  }

   set matchWinner(MatchPlayer mP){
    winner = mP;
  }




}
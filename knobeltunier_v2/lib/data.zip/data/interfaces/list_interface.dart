
abstract class ListInterface {
  void read();
  void save();
}